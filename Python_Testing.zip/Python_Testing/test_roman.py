# test_roman.py
# This file tests the convert() and convert_strict() functions from roman.py
# Run these tests with: pytest test_roman.py -v

from roman import convert, convert_strict


# --- single digit ---
def test_single_digit_I():
    assert convert("I") == 1

def test_single_digit_V():
    assert convert("V") == 5


# --- multiple same digits ---
def test_multiple_digits():
    assert convert("III") == 3


# --- different digits added together ---
def test_different_digits():
    assert convert("VI") == 6
    assert convert("XVI") == 16


# --- subtractive notation ---
def test_subtractive_IV():
    assert convert("IV") == 4

def test_subtractive_IX():
    assert convert("IX") == 9

def test_subtractive_XL():
    assert convert("XL") == 40

def test_subtractive_XC():
    assert convert("XC") == 90


# --- digit + subtractive combined ---
def test_combined():
    assert convert("XIX") == 19       # 10 + 9
    assert convert("MCMXCIV") == 1994 # M + CM + XC + IV


# --- boundary case (largest standard Roman numeral) ---
def test_boundary_max_value():
    assert convert("MMMCMXCIX") == 3999


# --- invalid input (using convert_strict, which catches everything) ---
def test_invalid_letter():
    try:
        convert_strict("ABC")        # A and B are not real Roman letters
        assert False, "Expected an error but got none"
    except ValueError:
        pass  # this is what we expect

def test_invalid_order():
    try:
        convert_strict("VX")         # V can never be subtracted
        assert False, "Expected an error but got none"
    except ValueError:
        pass

def test_invalid_repeat():
    try:
        convert_strict("XXC")        # can't subtract a repeated letter like this
        assert False, "Expected an error but got none"
    except ValueError:
        pass

def test_invalid_empty():
    try:
        convert_strict("")           # empty string is not valid
        assert False, "Expected an error but got none"
    except ValueError:
        pass