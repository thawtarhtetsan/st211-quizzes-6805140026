# roman.py
# This file converts a Roman numeral string (like "XIV") into a number (like 14)


# This dictionary stores the value of each Roman letter
values = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000
}

# Only these letters are allowed to be "subtracted" before a bigger one.
# I can go before V or X   (IV=4, IX=9)
# X can go before L or C   (XL=40, XC=90)
# C can go before D or M   (CD=400, CM=900)
# Anything else, like V before X ("VX"), is NOT allowed.
allowed_subtract = {
    "I": ["V", "X"],
    "X": ["L", "C"],
    "C": ["D", "M"]
}


def convert(number):
    # Turns a Roman numeral string into an integer.
    total = 0  # this will hold the final answer

    # go through each letter in the string one by one
    for i in range(len(number)):
        letter = number[i]

        # check the letter is a real Roman numeral letter
        if letter not in values:
            raise ValueError(f"'{letter}' is not a valid Roman numeral letter")

        current = values[letter]  # value of current letter

        # check if there is a letter after this one
        if i + 1 < len(number):
            next_letter = number[i + 1]

            if next_letter not in values:
                raise ValueError(f"'{next_letter}' is not a valid Roman numeral letter")

            next_value = values[next_letter]

            # if current letter is smaller than the next one,
            # it means "subtract" (like IV = 4, IX = 9)
            if current < next_value:
                # make sure this is actually an allowed subtraction
                if letter not in allowed_subtract or next_letter not in allowed_subtract[letter]:
                    raise ValueError(f"'{letter}{next_letter}' is not valid Roman numeral notation")
                total -= current
            else:
                total += current
        else:
            # this is the last letter, just add it
            total += current

    return total


def to_roman(num):
    # This is the OPPOSITE of convert(): turns a number back into Roman letters.
    # We use this inside convert_strict() to double-check the input was really valid.
    number_map = [
        (1000, "M"), (900, "CM"), (500, "D"), (400, "CD"),
        (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
        (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")
    ]
    result = ""
    for value, symbol in number_map:
        while num >= value:
            result += symbol
            num -= value
    return result


def convert_strict(number):
    # This is the SAFE version to use for user input.
    # It calls convert() first, then double-checks the answer by
    # converting the number BACK into Roman letters. If it doesn't
    # match what was typed, the input was invalid (catches things
    # like "XXC" or "IIII" that convert() alone would miss).
    number = number.upper()

    if number == "":
        raise ValueError("Empty input is not a valid Roman numeral")

    total = convert(number)

    if to_roman(total) != number:
        raise ValueError(f"'{number}' is not a valid Roman numeral")

    return total


# This block only runs when you run "python3 roman.py" directly.
# It will NOT run when this file is imported by test_roman.py.
if __name__ == "__main__":
    numeral = input("Enter a Roman numeral: ")

    try:
        result = convert_strict(numeral)
        print(result)
    except ValueError:
        print("Invalid input")